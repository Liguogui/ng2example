### Angular Documentation Example 

Lifecycle Hooks