### Angular Documentation Example 

Module-relative Paths