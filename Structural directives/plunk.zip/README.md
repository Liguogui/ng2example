### Angular Documentation Example 

Structural directives