### Angular Documentation Example 

Angular Animations