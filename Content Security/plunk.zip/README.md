### Angular Documentation Example 

Content Security