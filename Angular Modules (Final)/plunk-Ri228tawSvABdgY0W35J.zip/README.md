### Angular Documentation Example 

NgModule Final