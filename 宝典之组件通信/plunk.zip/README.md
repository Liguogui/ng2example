### Angular Documentation Example 

Component Communication Cookbook samples