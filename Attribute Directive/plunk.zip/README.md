### Angular Documentation Example 

Attribute Directive