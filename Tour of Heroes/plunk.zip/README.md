### Angular Documentation Example 

Tour of Heroes: Part 6