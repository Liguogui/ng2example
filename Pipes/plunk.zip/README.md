### Angular Documentation Example 

Pipes