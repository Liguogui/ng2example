### Angular Documentation Example 

Component Styles